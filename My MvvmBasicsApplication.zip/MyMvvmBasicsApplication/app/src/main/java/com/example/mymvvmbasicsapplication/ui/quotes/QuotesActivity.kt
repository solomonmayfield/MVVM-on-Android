package com.example.mymvvmbasicsapplication.ui.quotes

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.example.mymvvmbasicsapplication.R
import com.example.mymvvmbasicsapplication.data.Quote
import com.example.mymvvmbasicsapplication.utilities.InjectorUtils
import kotlinx.android.synthetic.main.activity_quotes.*


/***
 *Android MVVM Kotlin Tutorial - LiveData + ViewModel (Android Architecture Components)
 * https://www.youtube.com/watch?v=d7UxPYxgBoA
 *
 * Model - View - ViewModel is an architectural pattern which will empower you to write manageable, maintainable, cleaner and testable code. MVVM is also supported and encouraged by Google itself. There are many first-party libraries like lifecycle-aware components, LiveData, ViewModel and many more.

In this tutorial you are going to put MVVM pattern into practice. You will build a simple, yet real-enough app which will make you understand MVVM on a deeper level. It will be an app displaying quotes which you put in. This quote app will have a ViewModel, Repository, fake database and a simple dependency injection. This will give you a strong foundation to build on.
 *
 *
 *
 *
 */
class QuotesActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    private fun intializeUI(){

        val factory = InjectorUtils.provideQuotesViewModelFactory()
        val viewModel = ViewModelProviders.of(this, factory)
            .get(QuotesViewModel::class.java)

        viewModel.getQuotes().observe(this, Observer { quotes -> val stringBuilder = StringBuilder()
        quotes.forEach{ quote -> stringBuilder.append("$quote\n\n")
        }
        textView_quotes.text =stringBuilder.toString()
        })


        button_add_quote.setOnClickListener {
            val quote = Quote(editText_quote.text.toString(), editText_author.toString())
            viewModel.addQuote(quote)
            editText_quote.setText("")
            editText_author.setText("")

        }
   }
}
