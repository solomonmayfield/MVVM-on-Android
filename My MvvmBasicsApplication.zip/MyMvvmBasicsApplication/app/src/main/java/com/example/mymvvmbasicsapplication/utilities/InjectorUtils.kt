package com.example.mymvvmbasicsapplication.utilities

import com.example.mymvvmbasicsapplication.data.FakeDatabase
import com.example.mymvvmbasicsapplication.data.QuoteRepository
import com.example.mymvvmbasicsapplication.ui.quotes.QuotesViewModelFactory

object InjectorUtils {

    fun provideQuotesViewModelFactory(): QuotesViewModelFactory{
        val quoteRepository = QuoteRepository.getInstance(FakeDatabase.getInstance().quoteDao)
        return QuotesViewModelFactory(quoteRepository)
    }
}